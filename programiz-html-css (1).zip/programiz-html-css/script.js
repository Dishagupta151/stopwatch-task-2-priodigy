let timer;
let [hours, minutes, seconds] = [0, 0, 0];
let running = false;

const display = document.getElementById('display');
const startBtn = document.getElementById('start');
const pauseBtn = document.getElementById('pause');
const resetBtn = document.getElementById('reset');
const lapBtn = document.getElementById('lap');
const lapsList = document.getElementById('laps');

function updateDisplay() {
  const h = hours < 10 ? '0' + hours : hours;
  const m = minutes < 10 ? '0' + minutes : minutes;
  const s = seconds < 10 ? '0' + seconds : seconds;
  display.textContent = `${h}:${m}:${s}`;
}

function runTimer() {
  seconds++;
  if (seconds === 60) {
    seconds = 0;
    minutes++;
  }
  if (minutes === 60) {
    minutes = 0;
    hours++;
  }
  updateDisplay();
}

startBtn.addEventListener('click', () => {
  if (!running) {
    timer = setInterval(runTimer, 1000);
    running = true;
  }
});

pauseBtn.addEventListener('click', () => {
  clearInterval(timer);
  running = false;
});

resetBtn.addEventListener('click', () => {
  clearInterval(timer);
  [hours, minutes, seconds] = [0, 0, 0];
  updateDisplay();
  lapsList.innerHTML = '';
  running = false;
});

lapBtn.addEventListener('click', () => {
  if (running) {
    const lapTime = display.textContent;
    const lapItem = document.createElement('li');
    lapItem.textContent = `Lap: ${lapTime}`;
    lapsList.appendChild(lapItem);
  }
});

updateDisplay();
